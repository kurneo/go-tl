package finder

import (
	"github.com/kurneo/go-template/internal"
)

func RegisterModule(app internal.Contract) error {
	//lg := app.GetLogger()
	//
	//r, err := datasource.New(cfg.Storage, lg)
	//
	//if err != nil {
	//	return err
	//}
	//
	//v1.New(app, usecase.New(lg, r))
	return nil
}
