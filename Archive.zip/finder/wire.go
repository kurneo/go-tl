package finder

import "github.com/google/wire"

var WireSet = wire.NewSet()
