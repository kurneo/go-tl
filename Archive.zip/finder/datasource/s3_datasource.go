package datasource

import (
	"github.com/kurneo/go-template/pkg/filesystem"
)

type S3Repo struct {
	mainStorage filesystem.S3DiskContract
	l           log.Contract
	pathHelper  PathHelper
	Ignores     []string
}
