package datasource

import (
	"github.com/kurneo/go-template/internal/finder/usecase"
	"github.com/kurneo/go-template/pkg/log"
)

func New(l log.Contract) (usecase.FinderRepositoryContract, error) {
	return nil, nil
}

func newLocal(l log.Contract) usecase.FinderRepositoryContract {
	//prefix := "files"
	//separator := "/"
	//
	//pathHelper := NewPathHelper(separator)
	//mainPreFixer := helper.NewPreFixer(
	//	pathHelper.Concat(pathHelper.StripSlash(c.Get("root")), prefix),
	//	separator,
	//)
	return LocalRepo{
		//mainStorage:    filesystem.NewPublicDisk(filesystem.NewLocalDriver(mainPreFixer, l), c.Get("url")),
		l: l,
		//pathHelper:     pathHelper,
		fileTypeHelper: NewFileTypeHelper(),
		Ignores:        []string{".gitkeep"},
	}
}

//func getConfig(disk string, cfg config.Storage) (config.DiskCfg, error) {
//	if c, ok := cfg.Disks[disk]; ok {
//		return c, nil
//	}
//	return nil, errors.New("missing config for filesystem disk: " + disk)
//}
